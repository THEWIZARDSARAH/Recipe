from django.contrib import admin
from .models import Recipe

# Register the Recipe model
admin.site.register(Recipe)